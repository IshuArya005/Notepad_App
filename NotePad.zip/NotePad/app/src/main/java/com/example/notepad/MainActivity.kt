package com.example.notepad

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var notes: MutableList<Note>
    private lateinit var adapter: NotesAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyStateLayout: LinearLayout
    private lateinit var sharedPreferences: SharedPreferences
    private val gson = Gson()

    private val colorList = listOf(
        R.color.note_color_1,
        R.color.note_color_2,
        R.color.note_color_3,
        R.color.note_color_4,
        R.color.note_color_5,
        R.color.note_color_6
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        sharedPreferences = getSharedPreferences("notes_prefs", Context.MODE_PRIVATE)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        recyclerView = findViewById(R.id.recyclerViewNotes)
        emptyStateLayout = findViewById(R.id.emptyStateLayout)
        
        setupRecyclerView()
        loadNotes()

        val fabAddNote = findViewById<ExtendedFloatingActionButton>(R.id.fabAddNote)
        fabAddNote.setOnClickListener {
            showAddNoteDialog()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_calendar -> {
                startActivity(Intent(this, CalendarActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun setupRecyclerView() {
        notes = mutableListOf()
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = NotesAdapter(notes) { position ->
            deleteNote(position)
        }
        recyclerView.adapter = adapter
    }

    private fun loadNotes() {
        val json = sharedPreferences.getString("notes_list", null)
        val type = object : TypeToken<MutableList<Note>>() {}.type
        val savedNotes: MutableList<Note>? = gson.fromJson(json, type)
        
        notes.clear()
        if (savedNotes != null) {
            notes.addAll(savedNotes)
        }
        adapter.notifyDataSetChanged()
        updateEmptyState()
    }

    private fun saveNotesToPrefs() {
        val json = gson.toJson(notes)
        sharedPreferences.edit().putString("notes_list", json).apply()
    }

    private fun showAddNoteDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Add New Note")

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(50, 40, 50, 10)

        val titleInput = EditText(this)
        titleInput.hint = "Title"
        layout.addView(titleInput)

        val descInput = EditText(this)
        descInput.hint = "Description"
        layout.addView(descInput)

        builder.setView(layout)

        builder.setPositiveButton("Add") { _, _ ->
            val title = titleInput.text.toString()
            val desc = descInput.text.toString()
            if (title.isNotEmpty() || desc.isNotEmpty()) {
                val date = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date())
                val randomColor = colorList[Random.nextInt(colorList.size)]
                
                val newNote = Note(title = title, description = desc, date = date, colorResId = randomColor)
                notes.add(0, newNote)
                adapter.notifyItemInserted(0)
                recyclerView.scrollToPosition(0)
                saveNotesToPrefs()
                updateEmptyState()
            } else {
                Toast.makeText(this, "Cannot add an empty note", Toast.LENGTH_SHORT).show()
            }
        }
        builder.setNegativeButton("Cancel", null)

        builder.show()
    }

    private fun deleteNote(position: Int) {
        notes.removeAt(position)
        adapter.notifyItemRemoved(position)
        adapter.notifyItemRangeChanged(position, notes.size)
        saveNotesToPrefs()
        updateEmptyState()
    }

    private fun updateEmptyState() {
        if (notes.isEmpty()) {
            recyclerView.visibility = View.GONE
            emptyStateLayout.visibility = View.VISIBLE
        } else {
            recyclerView.visibility = View.VISIBLE
            emptyStateLayout.visibility = View.GONE
        }
    }
}